/**
 * ============================================================
 * SHOP360 — Google Sheets Backend (Google Apps Script)
 * ============================================================
 * HOW TO USE:
 * 1. Create a Google Sheet with these tabs, named exactly:
 *      "Products"  "Orders"  "Messages"  "Users"  "Carts"  "Wishlist"
 *
 * 2. Products tab — first row must be these exact headers:
 *    ID | Name | Category | Price | DiscountPrice | Stock | Images | Variants | Description | Status
 *
 *    - Images: one or more image URLs separated by commas
 *    - Variants: e.g. "S,M,L,XL" or "Blue,Black,Maroon" (leave blank if none)
 *    - Status: Active or Hidden (Hidden products won't show on the site)
 *
 * 3. Orders tab — first row must be these exact headers (this
 *    script fills them in automatically, just create the header row once):
 *    OrderID | Date | Name | Phone | Street | City | Postal | Notes |
 *    PaymentMethod | TxnID | Items | Subtotal | Shipping | Total | Status
 *
 * 4. Messages tab — first row must be these exact headers (this
 *    script fills them in automatically, just create the header row once):
 *    Date | Name | Phone | Message
 *    This is where messages from the Contact page form land.
 *
 * 5. Users tab — first row must be these exact headers (this script
 *    fills them in automatically when someone creates an account):
 *    Phone | PasswordHash | Salt | Name | Email | Address | City | CreatedAt
 *    This powers customer accounts (My Account / profile.html).
 *    Passwords are never stored in plain text — only a salted SHA-256 hash.
 *
 * 6. Carts tab — first row must be these exact headers:
 *    Phone | CartJson | UpdatedAt
 *    This lets a logged-in customer's cart follow them across devices.
 *
 * 7. Wishlist tab — first row must be these exact headers:
 *    Phone | ProductID | AddedAt
 *    Lets logged-in customers save products for later ("heart" icon).
 *
 * 8. In this Sheet: Extensions -> Apps Script. Delete any starter
 *    code and paste this whole file in. Save.
 *
 * 9. Click Deploy -> New deployment -> gear icon -> "Web app"
 *      - Execute as: Me
 *      - Who has access: Anyone
 *    Click Deploy, authorize the permissions it asks for.
 *
 * 10. Copy the "Web app URL" it gives you. Paste it into
 *     CONFIG.API_URL inside js/api.js on your website.
 *
 * 11. Every time you change product info, just edit the "Products"
 *     sheet directly — no code changes, no redeploy needed.
 * ============================================================
 */

const PRODUCTS_SHEET = "Products";
const ORDERS_SHEET = "Orders";
const MESSAGES_SHEET = "Messages";
const USERS_SHEET = "Users";
const CARTS_SHEET = "Carts";
const WISHLIST_SHEET = "Wishlist";

function doGet(e){
  const action = e.parameter.action;
  if(action === "getProducts") return jsonResponse(getProducts());
  if(action === "trackOrder") return jsonResponse(trackOrder(e.parameter.orderId, e.parameter.phone));
  if(action === "getOrders") return jsonResponse(getOrdersByPhone(e.parameter.phone));
  if(action === "getCart") return jsonResponse(getCart(e.parameter.phone));
  if(action === "getWishlist") return jsonResponse(getWishlist(e.parameter.phone));
  return jsonResponse({ error: "Unknown action" });
}

function doPost(e){
  const action = e.parameter.action;
  const body = JSON.parse(e.postData.contents || "{}");
  if(action === "createOrder") return jsonResponse(createOrder(body));
  if(action === "createMessage") return jsonResponse(createMessage(body));
  if(action === "signup") return jsonResponse(signup(body));
  if(action === "login") return jsonResponse(login(body));
  if(action === "updateProfile") return jsonResponse(updateProfile(body));
  if(action === "changePassword") return jsonResponse(changePassword(body));
  if(action === "saveCart") return jsonResponse(saveCart(body));
  if(action === "toggleWishlist") return jsonResponse(toggleWishlist(body));
  return jsonResponse({ error: "Unknown action" });
}

/* ---------------- PRODUCTS ---------------- */
function getProducts(){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(PRODUCTS_SHEET);
  if(!sheet) return { products: [] };

  const data = sheet.getDataRange().getValues();
  const headers = data[0].map(h => String(h).trim());
  const rows = data.slice(1);

  const products = rows
    .filter(r => r[0] !== "" && r[0] !== null) // skip blank rows
    .map(r => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = r[i]);
      return {
        id: String(obj.ID),
        name: obj.Name,
        category: obj.Category,
        price: Number(obj.Price) || 0,
        discountPrice: Number(obj.DiscountPrice) || 0,
        stock: Number(obj.Stock) || 0,
        images: String(obj.Images || "").split(",").map(s => s.trim()).filter(Boolean),
        variants: obj.Variants || "",
        description: obj.Description || "",
        status: obj.Status || "Active"
      };
    });

  return { products };
}

/* ---------------- ORDERS ---------------- */
function createOrder(order){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(ORDERS_SHEET);
  if(!sheet) return { success: false, error: "Orders sheet not found" };

  const orderId = "ORD-" + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT", "yyMMdd") + "-" + Math.floor(1000 + Math.random()*9000);

  sheet.appendRow([
    orderId,
    new Date(),
    order.fullName || "",
    order.phone || "",
    order.street || "",
    order.city || "",
    order.postal || "",
    order.notes || "",
    order.paymentMethod || "",
    order.txnId || "",
    order.items || "",
    order.subtotal || 0,
    order.shipping || 0,
    order.total || 0,
    "Pending"
  ]);

  // Optional: reduce stock automatically for each item ordered.
  // Uncomment below if your Items field always matches product names exactly.
  // adjustStock(order.itemsJson);

  return { success: true, orderId: orderId };
}

/* Optional helper: decrease stock counts after an order (basic version) */
function adjustStock(itemsJson){
  try{
    const items = JSON.parse(itemsJson || "[]");
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(PRODUCTS_SHEET);
    const data = sheet.getDataRange().getValues();
    items.forEach(item => {
      for(let i=1;i<data.length;i++){
        if(String(data[i][0]) === String(item.id)){
          const stockCol = 6; // column F = Stock (1-indexed: A=1..F=6)
          const currentStock = Number(data[i][5]) || 0;
          sheet.getRange(i+1, stockCol).setValue(Math.max(0, currentStock - item.qty));
        }
      }
    });
  }catch(err){
    Logger.log("Stock adjust error: " + err);
  }
}

/* ---------------- MESSAGES (contact form) ---------------- */
function createMessage(msg){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(MESSAGES_SHEET);
  if(!sheet) return { success: false, error: "Messages sheet not found" };

  sheet.appendRow([
    new Date(),
    msg.name || "",
    msg.phone || "",
    msg.message || ""
  ]);

  return { success: true };
}

/* ---------------- TRACK ORDER ---------------- */
function trackOrder(orderId, phone){
  if(!orderId) return { found: false, error: "Order ID is required" };

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(ORDERS_SHEET);
  if(!sheet) return { found: false, error: "Orders sheet not found" };

  const data = sheet.getDataRange().getValues();
  const headers = data[0].map(h => String(h).trim());
  const rows = data.slice(1);

  const idIdx = headers.indexOf("OrderID");
  const phoneIdx = headers.indexOf("Phone");

  const normalizedInput = String(orderId).trim().toUpperCase();
  const normalizedPhone = String(phone || "").replace(/[\s-]/g, "");

  for(const r of rows){
    if(String(r[idIdx]).trim().toUpperCase() === normalizedInput){
      // if a phone was provided, it must match (last 10 digits) for privacy
      if(normalizedPhone){
        const sheetPhone = String(r[phoneIdx] || "").replace(/[\s-]/g, "");
        if(!sheetPhone.endsWith(normalizedPhone.slice(-10))) {
          return { found: false, error: "Order ID and phone number don't match." };
        }
      }
      const obj = {};
      headers.forEach((h, i) => obj[h] = r[i]);
      return {
        found: true,
        orderId: obj.OrderID,
        date: obj.Date instanceof Date ? obj.Date.toISOString() : String(obj.Date),
        name: obj.Name,
        city: obj.City,
        items: obj.Items,
        paymentMethod: obj.PaymentMethod,
        total: obj.Total,
        status: obj.Status || "Pending"
      };
    }
  }
  return { found: false, error: "No order found with that ID." };
}

/* ---------------- ACCOUNTS (Users tab) ---------------- */
function normPhone(phone){
  return String(phone || "").replace(/[\s-]/g, "");
}

function hashPassword(password, salt){
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, password + salt);
  return bytes.map(b => ((b < 0 ? b + 256 : b).toString(16)).padStart(2, "0")).join("");
}

function findUserRow(sheet, phone){
  const data = sheet.getDataRange().getValues();
  const p = normPhone(phone);
  for(let i = 1; i < data.length; i++){
    if(normPhone(data[i][0]) === p) return { rowIndex: i + 1, row: data[i] };
  }
  return null;
}

function signup(data){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(USERS_SHEET);
  if(!sheet) return { success: false, error: "Users sheet not found" };

  const phone = normPhone(data.phone);
  if(!/^03\d{9}$/.test(phone)) return { success: false, error: "Enter a valid Pakistani mobile number (03XXXXXXXXX)." };
  if(!data.password || data.password.length < 6) return { success: false, error: "Password must be at least 6 characters." };
  if(!data.name) return { success: false, error: "Name is required." };
  if(findUserRow(sheet, phone)) return { success: false, error: "An account with this phone number already exists. Try logging in." };

  const salt = Utilities.getUuid();
  const hash = hashPassword(data.password, salt);

  sheet.appendRow([
    phone, hash, salt, data.name || "", data.email || "", data.address || "", data.city || "", new Date()
  ]);

  return { success: true, profile: { phone, name: data.name, email: data.email||"", address: data.address||"", city: data.city||"" } };
}

function login(data){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(USERS_SHEET);
  if(!sheet) return { success: false, error: "Users sheet not found" };

  const found = findUserRow(sheet, data.phone);
  if(!found) return { success: false, error: "No account found with that phone number." };

  const [phone, storedHash, salt, name, email, address, city] = found.row;
  const inputHash = hashPassword(data.password || "", salt);
  if(inputHash !== storedHash) return { success: false, error: "Incorrect password." };

  return { success: true, profile: { phone: normPhone(phone), name, email, address, city } };
}

function updateProfile(data){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(USERS_SHEET);
  if(!sheet) return { success: false, error: "Users sheet not found" };

  const found = findUserRow(sheet, data.phone);
  if(!found) return { success: false, error: "Account not found." };

  // columns: A Phone | B PasswordHash | C Salt | D Name | E Email | F Address | G City | H CreatedAt
  sheet.getRange(found.rowIndex, 4).setValue(data.name || "");
  sheet.getRange(found.rowIndex, 5).setValue(data.email || "");
  sheet.getRange(found.rowIndex, 6).setValue(data.address || "");
  sheet.getRange(found.rowIndex, 7).setValue(data.city || "");

  return { success: true };
}

function changePassword(data){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(USERS_SHEET);
  if(!sheet) return { success: false, error: "Users sheet not found" };

  const found = findUserRow(sheet, data.phone);
  if(!found) return { success: false, error: "Account not found." };

  const [, storedHash, salt] = found.row;
  const currentHash = hashPassword(data.currentPassword || "", salt);
  if(currentHash !== storedHash) return { success: false, error: "Current password is incorrect." };
  if(!data.newPassword || data.newPassword.length < 6) return { success: false, error: "New password must be at least 6 characters." };

  const newSalt = Utilities.getUuid();
  const newHash = hashPassword(data.newPassword, newSalt);
  sheet.getRange(found.rowIndex, 2).setValue(newHash);
  sheet.getRange(found.rowIndex, 3).setValue(newSalt);

  return { success: true };
}

/* ---------------- ORDER HISTORY (by phone, for logged-in accounts) ---------------- */
function getOrdersByPhone(phone){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(ORDERS_SHEET);
  if(!sheet) return { orders: [] };
  if(!phone) return { orders: [] };

  const data = sheet.getDataRange().getValues();
  const headers = data[0].map(h => String(h).trim());
  const rows = data.slice(1);
  const p = normPhone(phone).slice(-10);

  const orders = rows
    .filter(r => normPhone(r[headers.indexOf("Phone")]).endsWith(p))
    .map(r => {
      const obj = {};
      headers.forEach((h, i) => obj[h] = r[i]);
      return {
        orderId: obj.OrderID,
        date: obj.Date instanceof Date ? obj.Date.toISOString() : String(obj.Date),
        items: obj.Items,
        paymentMethod: obj.PaymentMethod,
        total: obj.Total,
        status: obj.Status || "Pending"
      };
    })
    .reverse(); // newest first

  return { orders };
}

/* ---------------- SAVED CART (Carts tab, follows logged-in customer across devices) ---------------- */
function saveCart(data){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CARTS_SHEET);
  if(!sheet) return { success: false, error: "Carts sheet not found" };

  const phone = normPhone(data.phone);
  if(!phone) return { success: false, error: "Phone is required" };

  const sheetData = sheet.getDataRange().getValues();
  for(let i = 1; i < sheetData.length; i++){
    if(normPhone(sheetData[i][0]) === phone){
      sheet.getRange(i + 1, 2).setValue(data.cartJson || "[]");
      sheet.getRange(i + 1, 3).setValue(new Date());
      return { success: true };
    }
  }
  sheet.appendRow([phone, data.cartJson || "[]", new Date()]);
  return { success: true };
}

function getCart(phone){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CARTS_SHEET);
  if(!sheet) return { cart: [] };

  const found = findUserRow(sheet, phone); // works generically: col A = Phone on this sheet too
  if(!found) return { cart: [] };
  try{
    return { cart: JSON.parse(found.row[1] || "[]") };
  }catch(err){
    return { cart: [] };
  }
}

/* ---------------- WISHLIST (heart icon on products) ---------------- */
function toggleWishlist(data){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(WISHLIST_SHEET);
  if(!sheet) return { success: false, error: "Wishlist sheet not found" };

  const phone = normPhone(data.phone);
  const productId = String(data.productId || "");
  if(!phone || !productId) return { success: false, error: "Missing phone or product id" };

  const sheetData = sheet.getDataRange().getValues();
  for(let i = 1; i < sheetData.length; i++){
    if(normPhone(sheetData[i][0]) === phone && String(sheetData[i][1]) === productId){
      sheet.deleteRow(i + 1);
      return { success: true, added: false };
    }
  }
  sheet.appendRow([phone, productId, new Date()]);
  return { success: true, added: true };
}

function getWishlist(phone){
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(WISHLIST_SHEET);
  if(!sheet) return { productIds: [] };

  const p = normPhone(phone);
  const data = sheet.getDataRange().getValues();
  const productIds = data.slice(1)
    .filter(r => normPhone(r[0]) === p)
    .map(r => String(r[1]));

  return { productIds };
}

/* ---------------- helpers ---------------- */
function jsonResponse(obj){
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
